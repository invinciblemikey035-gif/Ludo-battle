# LudoBattle

Firebase-connected Android multiplayer starter for `com.example.ludobattle`.

## Included
- Anonymous Firebase Authentication
- Realtime Database room creation/joining
- 6-character private room codes
- 4-player lobby foundation
- GitHub Actions debug APK build

## Firebase
Place the Firebase `google-services.json` for package `com.example.ludobattle` in `app/`.
For development the current Realtime Database rules can allow authenticated access under `/rooms`. Before release, tighten rules to validate room membership and allowed fields.

## Build
GitHub: upload the project, push to `main`, then open **Actions → Build LudoBattle APK**. The APK is published as an artifact.

This is an original implementation and does not include Ludo Star proprietary assets, branding, or code.

## Board preview
The starter now includes a custom-drawn Ludo board with four colored home areas and 4 tokens per color (16 total), plus a local dice-roll preview. This is a visual/game foundation; full server-authoritative movement rules are the next phase.
