package com.example.ludobattle;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.Random;

public class LudoBoardView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] colors = {Color.rgb(229,57,53), Color.rgb(251,192,45), Color.rgb(67,160,71), Color.rgb(30,136,229)};
    private final int[] dark = {Color.rgb(183,28,28), Color.rgb(245,124,0), Color.rgb(27,94,32), Color.rgb(13,71,161)};
    private int dice = 1;
    private final Random random = new Random();

    public LudoBoardView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float size = Math.min(getWidth(), getHeight());
        float left = (getWidth() - size) / 2f;
        float top = (getHeight() - size) / 2f;
        float cell = size / 15f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE); c.drawRoundRect(left, top, left+size, top+size, 24, 24, p);

        drawHomes(c,left,top,cell);
        drawTrack(c,left,top,cell);
        drawCenter(c,left,top,cell);
        drawTokens(c,left,top,cell);
        drawGrid(c,left,top,cell);
    }

    private void drawHomes(Canvas c,float l,float t,float s) {
        home(c,l,t,s,0,0,colors[0]);
        home(c,l,t,s,9,0,colors[1]);
        home(c,l,t,s,0,9,colors[2]);
        home(c,l,t,s,9,9,colors[3]);
    }
    private void home(Canvas c,float l,float t,float s,int gx,int gy,int color) {
        p.setColor(color); c.drawRect(l+gx*s,t+gy*s,l+(gx+6)*s,t+(gy+6)*s,p);
        p.setColor(Color.WHITE); c.drawRoundRect(l+(gx+1)*s,t+(gy+1)*s,l+(gx+5)*s,t+(gy+5)*s,18,18,p);
        p.setColor(Color.rgb(Color.red(color),Color.green(color),Color.blue(color))); p.setAlpha(35);
        c.drawRoundRect(l+(gx+1)*s,t+(gy+1)*s,l+(gx+5)*s,t+(gy+5)*s,18,18,p); p.setAlpha(255);
        float[][] pos={{1.9f,1.9f},{4.1f,1.9f},{1.9f,4.1f},{4.1f,4.1f}};
        p.setShadowLayer(5,0,2,0x55000000);
        for(float[] q:pos){ p.setColor(color); c.drawCircle(l+(gx+q[0])*s,t+(gy+q[1])*s,s*.62f,p); p.setColor(Color.WHITE); c.drawCircle(l+(gx+q[0])*s,t+(gy+q[1])*s,s*.30f,p); }
        p.clearShadowLayer();
    }
    private void drawTrack(Canvas c,float l,float t,float s) {
        // White cross lanes.
        p.setColor(Color.rgb(245,245,245));
        c.drawRect(l+6*s,t,l+9*s,t+15*s,p);
        c.drawRect(l,t+6*s,l+15*s,t+9*s,p);
        // Colored home lanes toward center.
        for(int i=0;i<6;i++){ p.setColor(colors[0]); c.drawRect(l+(6+i%1)*s,t+(5-i)*s,l+9*s,t+(6-i)*s,p); }
        for(int i=0;i<6;i++){ p.setColor(colors[1]); c.drawRect(l+(9+i)*s,t+6*s,l+(10+i)*s,t+9*s,p); }
        for(int i=0;i<6;i++){ p.setColor(colors[2]); c.drawRect(l+6*s,t+(9+i)*s,l+9*s,t+(10+i)*s,p); }
        for(int i=0;i<6;i++){ p.setColor(colors[3]); c.drawRect(l+(5-i)*s,t+6*s,l+(6-i)*s,t+9*s,p); }
        // Safe/star cells.
        p.setColor(Color.rgb(255,193,7));
        float[][] stars={{1.5f,6.5f},{8.5f,1.5f},{13.5f,8.5f},{6.5f,13.5f}};
        for(float[] a:stars){ drawStar(c,l+a[0]*s,t+a[1]*s,s*.28f); }
    }
    private void drawCenter(Canvas c,float l,float t,float s) {
        Path path=new Path();
        path.moveTo(l+7.5f*s,t+7.5f*s); path.lineTo(l+6*s,t+6*s); path.lineTo(l+6*s,t+9*s); path.close();
        p.setColor(colors[0]);c.drawPath(path,p);
        path.reset();path.moveTo(l+7.5f*s,t+7.5f*s);path.lineTo(l+9*s,t+6*s);path.lineTo(l+9*s,t+9*s);path.close();p.setColor(colors[1]);c.drawPath(path,p);
        path.reset();path.moveTo(l+7.5f*s,t+7.5f*s);path.lineTo(l+6*s,t+6*s);path.lineTo(l+9*s,t+6*s);path.close();p.setColor(colors[3]);c.drawPath(path,p);
        path.reset();path.moveTo(l+7.5f*s,t+7.5f*s);path.lineTo(l+6*s,t+9*s);path.lineTo(l+9*s,t+9*s);path.close();p.setColor(colors[2]);c.drawPath(path,p);
    }
    private void drawTokens(Canvas c,float l,float t,float s) {
        // Extra visible pieces on the starting cells, 4 per color.
        float[][] centers={{7.2f,1.5f},{8.5f,2.5f},{7.2f,13.5f},{6.5f,12.5f},{1.5f,7.2f},{2.5f,6.5f},{13.5f,7.2f},{12.5f,8.5f}};
        int[][] idx={{0,0,1,1},{2,2,3,3}};
        for(int color=0;color<4;color++){
            float[][] pts;
            if(color==0) pts=new float[][]{{2,2},{4,2},{2,4},{4,4}};
            else if(color==1) pts=new float[][]{{11,2},{13,2},{11,4},{13,4}};
            else if(color==2) pts=new float[][]{{2,11},{4,11},{2,13},{4,13}};
            else pts=new float[][]{{11,11},{13,11},{11,13},{13,13}};
            for(float[] q:pts) token(c,l+q[0]*s,t+q[1]*s,s*.55f,colors[color]);
        }
    }
    private void token(Canvas c,float x,float y,float r,int color){
        p.setShadowLayer(5,0,2,0x66000000);p.setColor(color);c.drawCircle(x,y,r,p);p.clearShadowLayer();
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.WHITE);c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);
        p.setColor(0x55FFFFFF);c.drawCircle(x-r*.22f,y-r*.22f,r*.18f,p);
    }
    private void drawGrid(Canvas c,float l,float t,float s){
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0x22000000);
        for(int i=0;i<=15;i++){c.drawLine(l+i*s,t,l+i*s,t+15*s,p);c.drawLine(l,t+i*s,l+15*s,t+i*s,p);}p.setStyle(Paint.Style.FILL);
    }
    private void drawStar(Canvas c,float x,float y,float r){
        Path q=new Path(); for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float rr=(i%2==0)?r:r*.45f;float px=x+(float)Math.cos(a)*rr,py=y+(float)Math.sin(a)*rr;if(i==0)q.moveTo(px,py);else q.lineTo(px,py);}q.close();c.drawPath(q,p);
    }
    public int rollDice(){dice=random.nextInt(6)+1;invalidate();return dice;}
}
