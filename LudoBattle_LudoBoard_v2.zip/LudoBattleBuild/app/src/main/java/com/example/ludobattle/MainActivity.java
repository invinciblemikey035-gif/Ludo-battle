package com.example.ludobattle;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    FirebaseAuth auth; DatabaseReference rooms; String uid;
    EditText roomCode; TextView status; ProgressBar progress; Button createRoom, joinRoom, rollDice; TextView diceText; LudoBoardView board;

    @Override protected void onCreate(Bundle b) { super.onCreate(b); setContentView(R.layout.activity_main);
        roomCode=findViewById(R.id.roomCode); status=findViewById(R.id.status); progress=findViewById(R.id.progress);
        createRoom=findViewById(R.id.createRoom); joinRoom=findViewById(R.id.joinRoom); board=findViewById(R.id.ludoBoard); rollDice=findViewById(R.id.rollDice); diceText=findViewById(R.id.diceText);
        auth=FirebaseAuth.getInstance(); rooms=FirebaseDatabase.getInstance().getReference("rooms");
        setBusy(true); auth.signInAnonymously().addOnCompleteListener(t -> { setBusy(false); if(t.isSuccessful()){ uid=auth.getCurrentUser().getUid(); status.setText("Connected • Ready to play"); } else status.setText("Firebase sign-in failed: "+t.getException()); });
        createRoom.setOnClickListener(v -> createRoom()); joinRoom.setOnClickListener(v -> joinRoom()); rollDice.setOnClickListener(v -> { int d=board.rollDice(); diceText.setText("🎲 "+d); });
    }
    void setBusy(boolean x){ progress.setVisibility(x?View.VISIBLE:View.GONE); createRoom.setEnabled(!x); joinRoom.setEnabled(!x); }
    String code(){ String chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; Random r=new Random(); StringBuilder s=new StringBuilder(); for(int i=0;i<6;i++)s.append(chars.charAt(r.nextInt(chars.length()))); return s.toString(); }
    void createRoom(){ if(uid==null)return; setBusy(true); String c=code(); DatabaseReference ref=rooms.child(c); Map<String,Object> room=new HashMap<>(); room.put("host",uid); room.put("status","waiting"); room.put("maxPlayers",4); room.put("createdAt",ServerValue.TIMESTAMP); Map<String,Object> p=new HashMap<>(); p.put("uid",uid); p.put("name","Player"); p.put("joinedAt",ServerValue.TIMESTAMP); Map<String,Object> players=new HashMap<>(); players.put(uid,p); room.put("players",players); ref.setValue(room).addOnCompleteListener(t->{setBusy(false); if(t.isSuccessful())showLobby(c); else status.setText("Could not create room");}); }
    void joinRoom(){ if(uid==null)return; String c=roomCode.getText().toString().trim().toUpperCase(Locale.US); if(c.length()!=6){status.setText("Enter a 6-character room code");return;} setBusy(true); DatabaseReference ref=rooms.child(c); ref.get().addOnCompleteListener(t->{ if(!t.isSuccessful()||!t.getResult().exists()){setBusy(false);status.setText("Room not found");return;} DataSnapshot snap=t.getResult(); Long max=snap.child("maxPlayers").getValue(Long.class); long count=snap.child("players").getChildrenCount(); if(count>=(max==null?4:max)){setBusy(false);status.setText("Room is full");return;} Map<String,Object> p=new HashMap<>();p.put("uid",uid);p.put("name","Player");p.put("joinedAt",ServerValue.TIMESTAMP);ref.child("players").child(uid).setValue(p).addOnCompleteListener(x->{setBusy(false);if(x.isSuccessful())showLobby(c);else status.setText("Could not join room");});}); }
    void showLobby(String c){ setContentView(R.layout.activity_main); roomCode=findViewById(R.id.roomCode);status=findViewById(R.id.status);progress=findViewById(R.id.progress);createRoom=findViewById(R.id.createRoom);joinRoom=findViewById(R.id.joinRoom);board=findViewById(R.id.ludoBoard);rollDice=findViewById(R.id.rollDice);diceText=findViewById(R.id.diceText); roomCode.setText(c); roomCode.setEnabled(false); createRoom.setText("ROOM CREATED: "+c); createRoom.setEnabled(false); joinRoom.setText("LEAVE / RETURN"); joinRoom.setOnClickListener(v->{rooms.child(c).child("players").child(uid).removeValue(); recreate();}); status.setText("Room "+c+" • Waiting for players…"); rooms.child(c).child("players").addValueEventListener(new ValueEventListener(){public void onDataChange(DataSnapshot s){status.setText("Room "+c+" • "+s.getChildrenCount()+"/4 players connected");} public void onCancelled(DatabaseError e){status.setText(e.getMessage());}}); }
}
